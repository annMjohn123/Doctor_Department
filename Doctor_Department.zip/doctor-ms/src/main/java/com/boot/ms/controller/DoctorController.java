package com.boot.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.ms.entity.Doctor;
import com.boot.ms.service.DoctorService;

@RestController
@RequestMapping("/doctors")
public class DoctorController {
	
	@Autowired
	DoctorService service;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Doctor>> getAllDoctors() {
		return new ResponseEntity<List<Doctor>>(service.getAllDoctors(), HttpStatus.OK);
	}
	
	@GetMapping("/getDoctor/{id}")
	public ResponseEntity<?>getDoctor(@PathVariable int id) {
		Doctor doctor = service.getDoctor(id);
		ResponseEntity<?> responseEntity = null;
		
		if(doctor == null) {
			responseEntity = new ResponseEntity<String>("No doctor present with given id" +id, HttpStatus.NOT_FOUND);
		}
		else {
			responseEntity = new ResponseEntity<Doctor>(doctor, HttpStatus.OK);
		}
		return responseEntity;
	}
	
	@GetMapping("/getDoctors/{departmentId}")
	public ResponseEntity<?> getDoctors(@PathVariable int departmentId) {
		List<Doctor> list = service.getDoctors(departmentId);
		ResponseEntity<?> responseEntity = null;
		if(list.isEmpty()) {
			responseEntity = new ResponseEntity<String>("No doctor present with given department id"+departmentId, HttpStatus.OK);
		}
		else {
			responseEntity = new ResponseEntity<List<Doctor>>(list, HttpStatus.OK);
		}
		return responseEntity;
	}
	
	@PostMapping("/addDoctor")
	public ResponseEntity<Doctor> addDoctor(@RequestBody Doctor doctor) {
		Doctor doctorData = service.addDoctor(doctor);
		return new ResponseEntity<Doctor>(doctorData, HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteDoctor/{id}")
	public List<Doctor> deleteDoctor(@PathVariable int id) {
		List<Doctor> list = service.deleteDoctor(id);
		ResponseEntity<?> responseEntity = null;
		if(list == null) {
			responseEntity = new ResponseEntity<String>("No doctor present with the given id" +id, HttpStatus.OK);
		}
		return list;
	}
	
	@PutMapping("/updateDoctor")
	public Doctor updateDoctor(@RequestBody Doctor doctor) {
		return service.updateDoctor(doctor);
	}
}
