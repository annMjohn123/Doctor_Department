package com.boot.ms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="doctor")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Doctor {
	
	@Id
	@Column(name="doct_id")
	private int id;
	@Column(name="doct_name")
	private String name;
	@Column(name="dept_id")
	private int departmentId;

}
