package com.boot.ms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.ms.entity.Doctor;
import com.boot.ms.repository.DoctorRepository;

@Service
public class DoctorService {
	
	@Autowired
	DoctorRepository repository;

	public List<Doctor> getAllDoctors() {
		return repository.findAll();
	}
	
	public Doctor getDoctor(int id) {
		return repository.findById(id).orElse(null);
	}
	
	public List<Doctor> getDoctors(int departmentId) {
		return repository.findAllByDepartmentId(departmentId);
	}
	
	public Doctor addDoctor(Doctor doctor) {
		return repository.save(doctor);
	}
	
	public List<Doctor> deleteDoctor(int id) {
		List<Doctor> list = null;
		Optional<Doctor> optional = repository.findById(id);
		if(optional.isPresent()) {
			repository.deleteById(id);
			list = getAllDoctors();
		}
		else {
			list = null;
		}
		return list;
	}
	
	public Doctor updateDoctor(Doctor doctor) {
		Doctor doctorData = repository.findById(doctor.getId()).get();
		doctorData.setName(doctor.getName());
		return repository.save(doctorData);
	}
}
