package com.boot.ms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.ms.entity.Department;
import com.boot.ms.repository.DepartmentRepository;

@Service
public class DepartmentService {
	
	@Autowired
	DepartmentRepository repository;
	
	public List<Department> getDepartments() {
		return repository.findAll();
	}
	
	public Department getDepartment(int id) {
		return repository.findById(id).orElse(null);
	}
	
	public Department addDepartment(Department department) {
		return repository.save(department);
	}
	
	public List<Department> deleteDepartment(int id) {
		List<Department> list = null;
		Optional<Department> optional = repository.findById(id);
		if(optional.isPresent()) {
			repository.deleteById(id);
			list = getDepartments();
		}
		else {
			list = null;
		}
		return list;
	}
	
	public Department updateDepartment(Department department) {
		Department departmentData = repository.findById(department.getId()).get();
		departmentData.setName(department.getName());
		return repository.save(departmentData);
	}

}
