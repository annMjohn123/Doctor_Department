package com.boot.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.boot.ms.entity.Department;
import com.boot.ms.model.DepartmentResponse;
import com.boot.ms.model.Doctor;
import com.boot.ms.service.DepartmentService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("/department")
@RibbonClient(name = "DOCTOR-MS")
public class DepartmentController {
	
	@Autowired
	DepartmentService service;
	
	@Autowired
	RestTemplate template;
	
	@SuppressWarnings("unchecked")
	@GetMapping("/getAll")
	@HystrixCommand(defaultFallback = "callFallBack")
	public ResponseEntity<?> getDepartments() {
		//List<Doctor> list = template.getForObject("http://DOCTOR-MS/doctors/getAll", List.class);
		return new ResponseEntity<List<Department>>(service.getDepartments(), HttpStatus.OK);
	}
	
	@GetMapping("/getDepartmentGroup/{id}")
	@HystrixCommand(defaultFallback = "callFallBack")
	public ResponseEntity<?>getDepartment(@PathVariable int id) {
		Department department = service.getDepartment(id);
		ResponseEntity<?> responseEntity = null;
		
		if(department == null) {
			responseEntity = new ResponseEntity<String> ("No department present with given id" +id, HttpStatus.OK);
		}
		else {
			responseEntity = new ResponseEntity<Department>(department, HttpStatus.OK);
		}
		return responseEntity;
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/getDepartmentAndDoctors/{id}")
	@HystrixCommand(defaultFallback = "callFallBack")
	public ResponseEntity<?> getDepartmentAndDoctors(@PathVariable int id) {

		Department department = service.getDepartment(id);
		ResponseEntity<?> responseEntity = null;

		if (department == null) {
			responseEntity = new ResponseEntity<String>("No department present with the given id: " +id, HttpStatus.NOT_FOUND);
		} 
		else {
			List<Doctor> orderList = template.getForObject("http://localhost:5222/doctors/getDoctors/" + department.getId(), List.class);
			
			DepartmentResponse response = new DepartmentResponse();
			response.setDepartment(department);
			response.setDoctor(orderList);
			
			responseEntity = new ResponseEntity<DepartmentResponse>(response, HttpStatus.OK);
		}
		return responseEntity;
	}
	
	@PostMapping("/addDepartment")
	@HystrixCommand(defaultFallback = "callFallBack")
	public ResponseEntity<?> addDepartment(@RequestBody Department department) {
		Department departmentData = service.addDepartment(department);
		return new ResponseEntity<Department>(departmentData, HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteDepartment/{id}")
	//@HystrixCommand(defaultFallback = "callFallBack")
	public List<?> deleteDepartment(@PathVariable int id) {
		List<Department> list = service.deleteDepartment(id);
		ResponseEntity<?> responseEntity = null;
		if(list == null) {
			responseEntity = new ResponseEntity<String>("No department present with the given id" +id, HttpStatus.OK);
		}
		return list;
	}
	
	@PutMapping("/updateDepartment")
	//@HystrixCommand(defaultFallback = "callFallBack")
	public Department updateDepartment(@RequestBody Department department) {
		return service.updateDepartment(department);
	}
	
	public ResponseEntity<?> callFallBack() {
		return new ResponseEntity<String>("Service is down......", HttpStatus.SERVICE_UNAVAILABLE);
	}
}
